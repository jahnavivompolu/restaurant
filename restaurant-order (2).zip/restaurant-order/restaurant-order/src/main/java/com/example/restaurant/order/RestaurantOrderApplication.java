package com.example.restaurant.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantOrderApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantOrderApplication.class, args);
	}

}
